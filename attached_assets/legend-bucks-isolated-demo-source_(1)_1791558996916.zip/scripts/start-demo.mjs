import { spawn, spawnSync } from 'node:child_process';
const env = { ...process.env, NODE_ENV: 'development', LEGEND_BUCKS_SANDBOX: 'true', VITE_LEGEND_BUCKS_SANDBOX: 'true', BASE_PATH: '/' };
if (!env.DATABASE_URL || env.DEMO_DB_CONFIRMATION !== 'isolated-demo-only') throw new Error('Set a NEW Replit PostgreSQL DATABASE_URL and DEMO_DB_CONFIRMATION=isolated-demo-only');
if (env.APP_URL?.includes('legend-bucks-portal.replit.app')) throw new Error('Refusing production APP_URL');
for (const args of [['--filter','@workspace/scripts','sandbox:seed'],['--filter','@workspace/api-server','build']]) {
  const result = spawnSync('pnpm', args, {env, stdio:'inherit'});
  if (result.status !== 0) process.exit(result.status || 1);
}
const api = spawn('node',['artifacts/api-server/dist/index.mjs'], {env:{...env,PORT:'5055'},stdio:'inherit'});
const web = spawn('pnpm',['--filter','@workspace/legend-bucks','dev'], {env:{...env,PORT:env.PORT || '3000'},stdio:'inherit'});
let stopping=false;
function stop(code=0) {if(stopping)return;stopping=true;web.kill();api.kill();setTimeout(()=>process.exit(code),300);}
for(const child of [api,web]) child.on('exit',(code)=>stop(code || 0));
process.on('SIGINT',()=>stop(0));process.on('SIGTERM',()=>stop(0));
console.log('Training demo only — isolated dummy data; no production checkout.');
